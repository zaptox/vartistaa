package com.vartista.www.vartista.util;

import com.vartista.www.vartista.modules.user.user_fragments.ServiceProviderDetailFragment;

public class CONST {


    public static final int FIND_SERVICE_IN_LIST_FRAGMENT=1;
    public static final int  SERVICE_PROVIDER_DETAIL_FRAGMENT=2;
    public static final int  BOOK_NOW__FRAGMENT=3;
    public static final int  MY_SERVICE_REQUEST_FRAGMENT=4;
    public static final int  EARNING_FRAGMENT=5;
    public static final int  MY_SERVICES_LIST_FRAGMENT=6;
    public static final int  CREATE_SERVICE_FRAGMENT=7;
    public static final int  UPLOAD_DOC_LIST_FRAGMENT=8;
    public static final int  ADDRESS_SET_FRAGMENT=9;
    public static final int  USER_PROFILE_FRAGMENT=10;
    public static final int  NOTIFIATION_FRAGMENT=11;
    public static final int  MY_COMPLETED_SERVIE_FRAGMENT=12;
    public static final int  MY_APPOINTMENT_FRAGMENT=13;
    public static final int  MY_RATINGS_REVIEW_FRAGMENT=14;
    public static final int  MY_SERVICE_MEETNG_FRAGMENT=15;
    public static final int  DOC_UPLOAD_FRAGMENT=16;



}
