package com.vartista.www.vartista.modules.user;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.vartista.www.vartista.R;

public class UserNotificationOnTime extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_notification_on_time);
    }
}