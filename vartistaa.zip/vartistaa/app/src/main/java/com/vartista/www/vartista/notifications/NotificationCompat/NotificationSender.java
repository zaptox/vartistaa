package com.vartista.www.vartista.notifications.NotificationCompat;


import android.support.v4.app.NotificationCompat;

public class NotificationSender {

    public static String NOTIFICATION_TITLE;
    public static int NOTFICATION_ID;
    public static String CHANNEL_ID="1";

    private void sendNotification(int NOTIFICATION_ID){

    }

}
