package com.vartista.www.vartista.notifications.NotificationCompat;

import android.app.AlarmManager;
import android.content.Context;

import static android.content.Context.ALARM_SERVICE;

public class AlarmManagment{

}